package com.zybooks.weightapp2;

public class DailyWeight {
    private long mWeightId;
    private long mUserId;
    private String mDate;
    private int mWeight;

    public int getWeight() {
        return mWeight;
    }
    public void setWeight(int weight) {
        mWeight = weight;
    }

    public String getDate() {
        return mDate;
    }
    public void setDate(String date) {
        mDate = date;
    }

    public long getWeightId() {
        return mWeightId;
    }
    public void setWeightId(long weightId) { mWeightId = weightId; }

    public long getUserId() {
        return mUserId;
    }
    public void setUserId(long userId) { mUserId = userId; }
}
