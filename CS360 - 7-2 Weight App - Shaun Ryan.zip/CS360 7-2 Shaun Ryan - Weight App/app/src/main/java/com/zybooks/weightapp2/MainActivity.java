package com.zybooks.weightapp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private EditText mUser;
    private EditText mPassword;
    private UserDatabase mUserDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mUser = findViewById(R.id.editTextPersonName);
        mPassword = findViewById(R.id.editTextPassword);
        mUserDb = UserDatabase.getInstance(getApplicationContext());
    }

    public void signInClicked(View view) {
        long validation = 2;
        String usernameString = mUser.getText().toString();
        String passwordString = mPassword.getText().toString();
        validation = mUserDb.validateUser(usernameString,passwordString);

        if(validation > 0) {
            Toast.makeText(getApplicationContext(), "User Validated", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, LogbookActivity.class);
            intent.putExtra("userSession",validation);
            startActivity(intent);
        }
        else if(validation == 0) {
            Toast.makeText(getApplicationContext(), "Password Incorrect", Toast.LENGTH_SHORT).show();
        }
        else if(validation == -1) {
            Toast.makeText(getApplicationContext(), "User Does Not Exist", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(getApplicationContext(), "Database Error", Toast.LENGTH_SHORT).show();
        }
    }

    public void newAccountClicked(View view) {
        String usernameString = mUser.getText().toString();
        String passwordString = mPassword.getText().toString();
        long userId = -2;
        userId = mUserDb.addUser(usernameString, passwordString);
        /*if(userId == -100) {
            Toast.makeText(getApplicationContext(), "User Already Exists", Toast.LENGTH_SHORT).show();
        }
        else if(userId == -2) {
            Toast.makeText(getApplicationContext(), "Database Error", Toast.LENGTH_SHORT).show();
        }*/

        Toast.makeText(getApplicationContext(), "User " + usernameString + " added" + userId, Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(this, EnterActivity.class);
        intent.putExtra("userSession",userId);
        startActivity(intent);

    }
}