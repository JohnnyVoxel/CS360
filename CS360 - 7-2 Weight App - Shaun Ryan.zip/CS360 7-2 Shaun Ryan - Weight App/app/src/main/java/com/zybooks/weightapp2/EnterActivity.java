package com.zybooks.weightapp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class EnterActivity extends AppCompatActivity {

    private UserDatabase mWeightDb;
    private long userSession = 0;
    private EditText mWeight;
    private EditText mDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            userSession = extras.getLong("userSession");
        }
        mWeightDb = UserDatabase.getInstance(getApplicationContext());
        mWeight = findViewById(R.id.editWeight);
        mDate = findViewById(R.id.editTextDate);
    }
    public void submitClicked(View view) {
        int weightVal = Integer.parseInt(mWeight.getText().toString());
        String dateVal = mDate.getText().toString();
        DailyWeight daily = new DailyWeight();
        daily.setUserId(userSession);
        daily.setDate(dateVal);
        daily.setWeight(weightVal);
        mWeightDb.addDailyWeight(daily);
        Intent intent = new Intent(this, LogbookActivity.class);
        startActivity(intent);
    }
    public void cancelClicked(View view) {
        Intent intent = new Intent(this, LogbookActivity.class);
        startActivity(intent);
    }
    @Override
    public boolean onCreateOptionsMenu(android.view.Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(android.view.MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                Intent intent = new Intent(this, SettingsActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}