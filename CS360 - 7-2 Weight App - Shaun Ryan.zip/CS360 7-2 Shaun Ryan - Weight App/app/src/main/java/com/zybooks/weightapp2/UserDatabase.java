package com.zybooks.weightapp2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

import java.util.List;

public class UserDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 1;

    private static UserDatabase mUserDb;
    private final static String TAG = "UserDatabase";

    public static UserDatabase getInstance(Context context) {
        if (mUserDb == null) {
            mUserDb = new UserDatabase(context);
        }
        return mUserDb;
    }

    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }
    private static final class WeightTable {
        private static final String TABLE = "weights";
        private static final String COL_ID = "_id";
        private static final String COL_USER = "userId";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USERNAME + ", " +
                UserTable.COL_PASSWORD + ", " +
                "foreign key(" + UserTable.COL_USERNAME + ") references " +
                UserTable.TABLE + "(" + UserTable.COL_PASSWORD + ") on delete cascade)");

        db.execSQL("create table " + UserDatabase.WeightTable.TABLE + " (" +
                UserDatabase.WeightTable.COL_ID + " integer primary key autoincrement, " +
                UserDatabase.WeightTable.COL_USER + ", " +
                UserDatabase.WeightTable.COL_DATE + ", " +
                UserDatabase.WeightTable.COL_WEIGHT + ", " +
                "foreign key(" + UserDatabase.WeightTable.COL_USER + ") references " +
                UserDatabase.WeightTable.TABLE + "(" + UserDatabase.WeightTable.COL_DATE + ") on delete cascade)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        db.execSQL("drop table if exists " + WeightTable.TABLE);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            //Enable foreign key constraints
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                db.execSQL("pragma foreign_keys = on;");
            } else {
                db.setForeignKeyConstraintsEnabled(true);
            }
        }
    }

    public long validateUser(String username, String password) {
        User user = null;
        String passwordTable = null;
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + UserTable.TABLE + " where " + UserTable.COL_USERNAME + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {username});

        if (cursor.moveToFirst()) {
            user = new User();
            user.setId(cursor.getInt(0));
            user.setUserName(cursor.getString(1));
            passwordTable = cursor.getString(2);
            user.setPassword(cursor.getString(2));
        } else
        {
            return -1;
        }
        if (passwordTable.equals(password)) {
            return user.getId();
        }
        else {
            return 0;
        }
    }

    public long addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UserTable.COL_USERNAME, username);
        values.put(UserTable.COL_PASSWORD, password);
        long userId = db.insert(UserTable.TABLE, null, values);

        return userId;
    }

    public void addDailyWeight(DailyWeight daily) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserDatabase.WeightTable.COL_USER, daily.getUserId());
        values.put(UserDatabase.WeightTable.COL_DATE, daily.getDate());
        values.put(UserDatabase.WeightTable.COL_WEIGHT, daily.getWeight());
        long id = db.insert(UserDatabase.WeightTable.TABLE, null, values);
        daily.setWeightId(id);
    }

    public DailyWeight getDailyWeight(long  weightId) {
        DailyWeight singleDailyWeight = null;
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + UserDatabase.WeightTable.TABLE + " where " + UserDatabase.WeightTable.COL_USER + " = ? order by " + UserDatabase.WeightTable.COL_DATE + " DESC Limit 1";
        Cursor cursor = db.rawQuery(sql, new String[] {String.valueOf(weightId)});

        if(cursor.moveToFirst()) {
            singleDailyWeight = new DailyWeight();
            singleDailyWeight.setWeightId(cursor.getLong(0));
            singleDailyWeight.setUserId(cursor.getLong(1));
            singleDailyWeight.setWeight(cursor.getInt(2));
            singleDailyWeight.setDate(cursor.getString(3));
            cursor.close();
            return singleDailyWeight;
        } else {
            return null;
        }

    }

    public List<DailyWeight> getAllDailyWeights(long userId) {
        List<DailyWeight> allDailyWeightList = null;
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + UserDatabase.WeightTable.TABLE + " where " + UserDatabase.WeightTable.COL_USER + " = ? order by " + UserDatabase.WeightTable.COL_DATE + " DESC";
        Cursor cursor = db.rawQuery(sql, new String[] {String.valueOf(userId)});

        if(cursor.moveToFirst()) {
            do {
                DailyWeight allDailyWeight = new DailyWeight();
                allDailyWeight.setWeightId(cursor.getLong(0));
                allDailyWeight.setUserId(cursor.getLong(1));
                allDailyWeight.setWeight(cursor.getInt(2));
                allDailyWeight.setDate(cursor.getString(3));
                allDailyWeightList.add(allDailyWeight);
            } while (cursor.moveToNext());
            cursor.close();
            return allDailyWeightList;
        } else {
            return null;
        }

    }

    public void deleteDailyWeight (long weightId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(UserDatabase.WeightTable.TABLE, UserDatabase.WeightTable.COL_ID + " = ?", new String[] {String.valueOf(weightId)});
    }

}
