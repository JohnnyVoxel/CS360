package com.zybooks.weightapp2;

public class User {
    private long mUserId;
    private String mUserName;
    private String mUserPassword;

    public String getUserName() {
        return mUserName;
    }
    public void setUserName(String userName) {
        mUserName = userName;
    }

    public String getPassword() {
        return mUserPassword;
    }
    public void setPassword(String password) {
        mUserPassword = password;
    }

    public long getId() {
        return mUserId;
    }
    public void setId(long id) {
        mUserId = id;
    }
}
